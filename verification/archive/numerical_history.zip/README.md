# Historical numerical computations

This archive preserves the earlier numerical and symbolic checks used while developing and reviewing *A uniform bound of five for Diophantine tuples in imaginary quadratic integer rings*. Use the current verification directory for the streamlined checks of the released article. This historical collection is for provenance and for inspection of additional independent computations.

## Contents

- `history/early/initial_audit`: polynomial and determinant checks, interval comparisons, first-pair and fixed-triple computations, small-pair graphs and Pell enumerations, with recorded outputs.
- `history/early/v1_review`: independently reconstructed v1 checks, exact overlap algebra, small-pair/triple/Pell checks and their outputs.
- `history/early/v1_comments`: proposed improvements, determinant checks, finite complement certificates and independent integer checks. `finite_reduction/explore.py` is exploratory floating-point work; the exact certificate is `certify.py`. The `literature/rank_cross_check.py` file is an exact endpoint-algebra computation despite its historical directory name.
- `historical-v2`: v2 numerical checks and retained v1 computational modules on which some of them depend.
- `history/v3`: bounded v3 approximation and completion checks. Earlier copies of these two algorithms are omitted because the v3 copies change only source binding, metadata and output destinations.
- `review-v3`: exact checks of the coefficient bound, determinant estimate, finite construction and small-element observations.

## Inputs, outputs and changes

The frozen input snapshots have `.txt` filenames and preserve the original source bytes, including formulas and tables. The programs parse these snapshots as text. They are not files to compile. Every corresponding quoted input pathname was changed from `.tex` to `.txt`; all changes, original hashes and packaged hashes are recorded in `ADAPTATIONS.json`. One nonmathematical auxiliary-file lookup of printed cross-reference numbers was omitted from `review-v3/review_v3_comments/checks/small_checks.py`; its mathematical assertions are unchanged.

The original recorded numerical results and calculation logs are included byte-for-byte. They predate this archive, so an old log may name the original input extension or a former working path. They are historical records, not a claim that every script has just been rerun. Some computations used superseded constants or explored alternatives; consult the current article and current verification directory for the released argument.

## Running selected computations

Use Python 3.10 or later. Some early symbolic computations additionally require SymPy; the historical requirement file states the version used. Many later checks use only the Python standard library. Work in an extracted copy: programs can overwrite their adjacent result files. For scripts whose outputs use relative paths, set the working directory to the corresponding stage root (for example `history/early/initial_audit`).

Examples, from the root of the extracted archive:

```sh
python history/v3/revision_v3/checks/approximation_check.py
python history/v3/revision_v3/checks/completion_check.py
python review-v3/review_v3_comments/checks/f3_exact.py
python review-v3/review_v3_comments/checks/vandermonde24_cross.py
python review-v3/review_v3_comments/checks/small_checks.py
```

Small-pair, small-triple and Pell computations are available through `historical-v2/revision_v2/checks/small_v2_exact.py` with the arguments `pairs`, `triples` and `pell`. These can take substantially longer. Importing an early script may itself start calculations. The initial first-pair script generates its own polynomial cache when no cache is present; no executable cache is supplied.

This is a curated historical collection, not a single uniform rerun command or a new execution of the large graph calculations. Numerical results still rely on the mathematical completeness arguments in the article. The archive assembly checked Python syntax, data integrity, inclusion of the frozen inputs and absence of unrelated project material; it did not rerun all computations.

`SHA256SUMS` covers every other archive member.
